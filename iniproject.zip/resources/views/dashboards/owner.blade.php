@extends('layouts.app')

@section('content')
    <div x-data="{ tab: 'overview' }" class="min-h-screen bg-[#FFF9F2] -m-8 p-8 font-sans">

        {{-- NAVBAR (Sama dengan Admin) --}}
        <div class="w-full bg-white px-8 py-4 flex justify-between items-center shadow-sm mb-8 border-b border-gray-100 rounded-3xl">
            <div class="flex items-center gap-4">
                <div class="bg-[#FF9F1C] p-2 rounded-xl text-white font-bold text-2xl w-12 h-12 flex items-center justify-center shadow-md">P</div>
                <span class="text-2xl font-bold text-gray-800">Arkiest <span class="text-amber-500 text-sm font-black uppercase ml-2 tracking-widest">Owner</span></span>
            </div>
            <div class="flex items-center gap-6">
                <div class="text-right hidden md:block">
                    <p class="text-[10px] font-black text-orange-400 uppercase tracking-widest leading-none mb-1">Owner Mode</p>
                    <p class="font-bold text-gray-800 italic">{{ auth()->user()->name }}</p>
                </div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="bg-red-50 text-red-500 px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-red-500 hover:text-white transition-all shadow-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </button>
                </form>
            </div>
        </div>

        {{-- STATS CARDS (Fokus ke Keuangan) --}}
        <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div class="bg-gradient-to-br from-emerald-500 to-teal-600 p-6 rounded-[2rem] shadow-xl shadow-emerald-100 text-white">
                <div class="flex justify-between items-center opacity-80 text-xs font-bold uppercase">
                    <span>Total Pendapatan</span>
                    <i class="fas fa-wallet text-2xl"></i>
                </div>
                <h2 class="text-3xl font-black mt-2">Rp {{ number_format($totalPendapatan, 0, ',', '.') }}</h2>
                <p class="text-[10px] mt-2 font-bold opacity-70">SINKRON DENGAN DATABASE</p>
            </div>

            <div class="bg-white p-6 rounded-[2rem] shadow-sm border border-amber-100">
                <div class="flex justify-between items-center text-amber-600 opacity-80 text-xs font-bold uppercase">
                    <span>Kendaraan Hari Ini</span>
                    <i class="fas fa-car text-2xl"></i>
                </div>
                <h2 class="text-4xl font-black mt-2 text-gray-800">{{ $kendaraanHariIni }}</h2>
            </div>

            <div class="bg-[#2D3436] p-6 rounded-[2rem] shadow-xl text-white">
                <div class="flex justify-between items-center opacity-60 text-xs font-bold uppercase">
                    <span>Total Petugas</span>
                    <i class="fas fa-user-tie text-2xl"></i>
                </div>
                <h2 class="text-4xl font-black mt-2">{{ $totalPetugas }}</h2>
            </div>
        </div>

        {{-- MAIN CONTENT --}}
        <div class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">

            {{-- KIRI: Monitoring Area (Sama konsepnya) --}}
            <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-amber-100">
                <h3 class="text-xl font-bold mb-6 italic text-gray-800"><i class="fas fa-map-marker-alt text-amber-500 mr-2"></i> Kepadatan Parkir</h3>
                <div class="space-y-6">
                    @foreach ($areas as $area)
                        @php
                            $jumlahParkir = $area->kapasitas - $area->slot_tersedia;
                            $persenTerisi = ($area->kapasitas > 0) ? ($jumlahParkir / $area->kapasitas) * 100 : 0;
                        @endphp
                        <div>
                            <div class="flex justify-between mb-2">
                                <span class="font-bold text-sm text-gray-700">{{ $area->nama_area }}</span>
                                <span class="font-black text-amber-600">{{ round($persenTerisi) }}%</span>
                            </div>
                            <div class="w-full bg-gray-100 rounded-full h-2">
                                <div class="bg-amber-400 h-2 rounded-full transition-all duration-1000" style="width: {{ $persenTerisi }}%"></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            {{-- KANAN: Log Aktivitas Terbaru --}}
            <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border border-amber-100">
                <h3 class="text-xl font-bold mb-6 italic text-gray-800"><i class="fas fa-history text-amber-500 mr-2"></i> Aktivitas Terakhir</h3>
                <div class="space-y-4">
                    @forelse ($logs as $log)
                        <div class="flex items-center gap-4 p-3 rounded-2xl border border-gray-50 hover:bg-amber-50/50 transition-all">
                            <div class="w-10 h-10 rounded-xl {{ $log->status == 'parkir' ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600' }} flex items-center justify-center">
                                <i class="fas {{ $log->status == 'parkir' ? 'fa-arrow-down' : 'fa-arrow-up' }}"></i>
                            </div>
                            <div class="flex-1">
                                <p class="text-xs font-black text-gray-800">{{ $log->plat_nomor }}</p>
                                <p class="text-[10px] text-gray-400 font-bold uppercase">{{ $log->nama_area }} • {{ $log->status }}</p>
                            </div>
                            <div class="text-right">
                                <p class="text-[9px] font-bold text-gray-400">{{ \Carbon\Carbon::parse($log->created_at)->diffForHumans() }}</p>
                                <p class="text-[10px] font-black text-amber-600 italic">Oleh: {{ $log->petugas_name ?? 'System' }}</p>
                            </div>
                        </div>
                    @empty
                        <p class="text-center text-gray-400 italic">Belum ada aktivitas.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
@endsection
