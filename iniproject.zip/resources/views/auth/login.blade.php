<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Login • PARKIEST</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        /* ===== PREMIUM PARK ANIMATION ===== */
        .scene {
            position: relative;
            height: 320px;
            border-radius: 24px;
            overflow: hidden;
            background: radial-gradient(1200px 400px at 30% 20%, rgba(255,255,255,.7), rgba(255,255,255,0) 50%),
                        linear-gradient(135deg, rgba(255,214,165,.75), rgba(253,186,116,.55), rgba(244,63,94,.45));
            box-shadow: 0 24px 60px rgba(0,0,0,.12);
        }

        .ground {
            position: absolute;
            left: -20%;
            right: -20%;
            bottom: -40px;
            height: 160px;
            background: linear-gradient(to right, rgba(0,0,0,.08), rgba(0,0,0,.03));
            transform: skewX(-8deg);
            border-radius: 999px;
            filter: blur(.2px);
        }

        .road {
            position: absolute;
            left: 22px; right: 22px;
            bottom: 44px;
            height: 84px;
            background: rgba(8, 0, 0, 0.12);
            border-radius: 999px;
            box-shadow: inset 0 8px 18px rgba(0,0,0,.10);
        }

        .lane {
            position:absolute;
            left: 46px; right: 120px;
            bottom: 83px;
            height: 4px;
            background: repeating-linear-gradient(
                to right,
                rgba(255,255,255,.75) 0 22px,
                rgba(198, 31, 31, 0) 22px 40px
            );
            border-radius: 999px;
            opacity: .8;
        }

        /* Booth */
        .booth {
            position:absolute;
            right: 32px;
            bottom: 96px;
            width: 74px;
            height: 110px;
            background: rgba(255,255,255,.75);
            border-radius: 18px;
            box-shadow: 0 18px 40px rgba(0,0,0,.12);
            backdrop-filter: blur(6px);
        }
        .booth::before{
            content:"";
            position:absolute;
            top: 12px; left: 12px; right: 12px;
            height: 24px;
            background: rgba(17,24,39,.10);
            border-radius: 10px;
        }

        /* Traffic light (optional premium touch) */
        .light {
            position:absolute;
            right: 126px;
            bottom: 112px;
            width: 18px;
            height: 44px;
            background: rgba(17,24,39,.15);
            border-radius: 999px;
            box-shadow: 0 10px 20px rgba(0,0,0,.10);
        }
        .light::before{
            content:"";
            position:absolute;
            top: 6px; left: 5px;
            width: 8px; height: 8px;
            border-radius: 999px;
            background: rgba(239,68,68,.95); /* red */
            box-shadow: 0 0 16px rgba(239,68,68,.35);
            animation: lightState 7s infinite ease-in-out;
        }
        .light::after{
            content:"";
            position:absolute;
            bottom: 6px; left: 5px;
            width: 8px; height: 8px;
            border-radius: 999px;
            background: rgba(34,197,94,.30); /* green dim */
            box-shadow: 0 0 16px rgba(34,197,94,.20);
            animation: lightState2 7s infinite ease-in-out;
        }

        /* Barrier arm */
        .barrier-base{
            position:absolute;
            right: 112px;
            bottom: 94px;
            width: 22px;
            height: 46px;
            border-radius: 12px;
            background: rgba(17,24,39,.18);
            box-shadow: 0 12px 26px rgba(0,0,0,.12);
        }
        .arm{
            position:absolute;
            right: 122px;
            bottom: 125px;
            width: 120px;
            height: 10px;
            border-radius: 999px;
            background: linear-gradient(to right, rgba(255,255,255,.92), rgba(255,255,255,.92));
            box-shadow: 0 14px 26px rgba(0,0,0,.12);
            transform-origin: right center;
            animation: armMove 7s infinite cubic-bezier(.4,0,.2,1);
        }
        .arm::before{
            content:"";
            position:absolute;
            inset: 0;
            border-radius: 999px;
            background: repeating-linear-gradient(
                45deg,
                rgba(239,68,68,.95) 0 16px,
                rgba(255,255,255,.0) 16px 32px
            );
            mix-blend-mode: multiply;
            opacity: .8;
        }

        /* Car (SVG-ish CSS) */
        .car {
            position:absolute;
            bottom: 64px;
            width: 150px;
            height: 66px;
            animation: carMove 7s infinite cubic-bezier(.4,0,.2,1);
            filter: drop-shadow(0 18px 22px rgba(0,0,0,.18));
        }
        .car .body{
            position:absolute;
            inset: 10px 0 0 0;
            background: linear-gradient(135deg, #0f172a, #111827);
            border-radius: 18px;
        }
        .car .hood{
            position:absolute;
            left: 22px;
            top: 16px;
            width: 56px;
            height: 22px;
            background: rgba(255,255,255,.18);
            border-radius: 10px;
        }
        .car .headlight{
            position:absolute;
            right: 12px;
            top: 28px;
            width: 10px;
            height: 10px;
            background: rgba(253,230,138,.9);
            border-radius: 999px;
            box-shadow: 0 0 18px rgba(253,230,138,.45);
        }
        .car .wheel{
            position:absolute;
            bottom: 0;
            width: 22px;
            height: 22px;
            background: #0b0f1a;
            border-radius: 999px;
            box-shadow: inset 0 0 0 3px rgba(255,255,255,.12);
        }
        .car .wheel.left{ left: 26px; }
        .car .wheel.right{ right: 26px; }

        /* Timing: start -> stop -> barrier up -> go */
        @keyframes carMove {
            0%   { transform: translateX(-180px); }
            38%  { transform: translateX(44%); }  /* approaching */
            52%  { transform: translateX(52%); }  /* stop near barrier */
            70%  { transform: translateX(52%); }  /* wait */
            100% { transform: translateX(120%); } /* pass */
        }

        @keyframes armMove {
            0%   { transform: rotate(0deg); }
            45%  { transform: rotate(0deg); }
            58%  { transform: rotate(-60deg); } /* open */
            85%  { transform: rotate(-60deg); }
            100% { transform: rotate(0deg); }
        }

        @keyframes lightState {
            0%,52% { background: rgba(239,68,68,.95); box-shadow: 0 0 16px rgba(239,68,68,.35); }
            60%,100% { background: rgba(239,68,68,.25); box-shadow: 0 0 16px rgba(239,68,68,.15); }
        }
        @keyframes lightState2 {
            0%,52% { background: rgba(34,197,94,.25); box-shadow: 0 0 16px rgba(34,197,94,.15); }
            60%,100% { background: rgba(34,197,94,.95); box-shadow: 0 0 18px rgba(34,197,94,.35); }
        }

        /* Respect accessibility */
        @media (prefers-reduced-motion: reduce) {
            .car, .arm, .light::before, .light::after { animation: none !important; }
        }
    </style>
</head>

<body class="min-h-screen bg-gradient-to-br from-orange-100 via-orange-200 to-rose-300">
<div class="min-h-screen flex items-center justify-center p-6">
    <div class="w-full max-w-6xl rounded-3xl overflow-hidden shadow-2xl bg-white/70 backdrop-blur">
        <div class="grid md:grid-cols-2">

            <!-- LEFT: Premium scene -->
            <div class="p-10 bg-white">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-4xl font-extrabold tracking-tight text-gray-900">PARKIEST</h1>
                        <p class="mt-2 text-gray-600">Sistem manajemen parkir multi-peran.</p>
                    </div>
                    <div class="text-xs text-gray-500 px-3 py-1 rounded-full bg-gray-100">v1</div>
                </div>

                <div class="mt-8 scene">
                    <div class="ground"></div>
                    <div class="road"></div>
                    <div class="lane"></div>

                    <div class="booth"></div>
                    <div class="light"></div>

                    <div class="barrier-base"></div>
                    <div class="arm"></div>

                    <div class="car">
                        <div class="body"></div>
                        <div class="hood"></div>
                        <div class="headlight"></div>
                        <div class="wheel left"></div>
                        <div class="wheel right"></div>
                    </div>

                    <div class="absolute left-6 top-6 text-[11px] text-gray-700/70 bg-white/50 px-3 py-1 rounded-full">
                        Mobil masuk • Palang buka • Parkir aman
                    </div>
                </div>

                <p class="mt-4 text-xs text-gray-500">
                    *Animasi dibuat dengan CSS (ringan & aman untuk demo ujikom).
                </p>
            </div>

            <!-- RIGHT: Login form -->
            <div class="p-10 bg-amber-200/60">
                <h2 class="text-3xl font-extrabold text-white text-center">WELCOME!</h2>
                <p class="text-white/90 text-center text-sm mt-1">Silahkan login untuk melanjutkan</p>

                <div class="mt-8">
                    <x-auth-session-status class="mb-4" :status="session('status')" />

                    <form method="POST" action="{{ route('login') }}" class="space-y-5">
                        @csrf

                        <div>
                            <x-input-label for="email" :value="__('Email')" class="text-white" />
                            <x-text-input id="email" class="mt-1 block w-full rounded-xl"
                                type="email" name="email" :value="old('email')" required autofocus />
                            <x-input-error :messages="$errors->get('email')" class="mt-2" />
                        </div>

                        <div>
                            <x-input-label for="password" :value="__('Password')" class="text-white" />
                            <x-text-input id="password" class="mt-1 block w-full rounded-xl"
                                type="password" name="password" required autocomplete="current-password" />
                            <x-input-error :messages="$errors->get('password')" class="mt-2" />
                        </div>

                        <div class="flex items-center justify-between">
                            <label class="inline-flex items-center text-white/90 text-sm">
                                <input type="checkbox" name="remember" class="rounded border-white/60 bg-white/40">
                                <span class="ms-2">Remember me</span>
                            </label>

                            @if (Route::has('password.request'))
                                <a class="text-sm text-white underline hover:no-underline" href="{{ route('password.request') }}">
                                    Forgot your password?
                                </a>
                            @endif
                        </div>

                        <button type="submit"
                            class="w-full rounded-xl bg-white text-gray-900 font-semibold py-3 shadow hover:shadow-md transition">
                            LOGIN
                        </button>
                    </form>

                    <p class="mt-6 text-center text-xs text-white/80">
                        Admin membuat akun Petugas/Owner • Register publik dimatikan
                    </p>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>
