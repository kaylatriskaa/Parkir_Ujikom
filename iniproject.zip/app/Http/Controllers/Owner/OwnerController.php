<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Models\Transaksi;
use App\Models\User;
use Illuminate\Http\Request;

class OwnerController extends Controller
{
    public function index()
    {
        // 1. Ambil data area untuk monitoring kapasitas
        $areas = Area::all();

        // 2. Query Log Aktivitas: Sekarang sudah bisa JOIN ke users karena kolom user_id sudah ada
        $logs = Transaksi::leftJoin('area_parkirs', 'transaksis.area_id', '=', 'area_parkirs.area_id')
                ->leftJoin('users', 'transaksis.user_id', '=', 'users.id')
                ->select(
                    'transaksis.*',
                    'area_parkirs.nama_area',
                    'users.name as petugas_name' // Mengambil nama petugas
                )
                ->latest('transaksis.created_at')
                ->take(10)
                ->get();

        // 3. Statistik untuk dashboard cards
        $totalPendapatan = Transaksi::where('status', 'selesai')->sum('total_bayar');
        $kendaraanHariIni = Transaksi::whereDate('created_at', today())->count();
        $totalPetugas = User::where('role', 'petugas')->count();

        return view('dashboards.owner', compact('areas', 'logs', 'totalPendapatan', 'kendaraanHariIni', 'totalPetugas'));
    }
}
